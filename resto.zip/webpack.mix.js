const mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.js('resources/js/app.js', 'public/js').
styles([
   // 'resources/plantilla/css/bootstrap.css',
   'resources/plantilla/css/dataTables.bootstrap4.min.css'],'public/css/dataTables.bootstrap4.min.css').
styles([
   'resources/plantilla/css/themify-icons/themify-icons.css',
],'public/css/themify-icons.css').
scripts([
   /*Core JS Files */
   
   'resources/plantilla/js/vendor.js',
   'resources/plantilla/js/bundle.js',
   'resources/plantilla/js/jquery-3.5.1.min.js',
   'resources/plantilla/js/popper.min.js',
   'resources/plantilla/js/bootstrap.min.js',
   'resources/plantilla/js/jquery.dataTables.min.js',
   /*jQuery UI */
   'resources/plantilla/js/dataTables.bootstrap4.min.js',
],'public/js/all.js')
   .sass('resources/sass/app.scss', 'public/css');

   /*
      esta linea de codigo la elimine de archivo bootstrap.min.js 
      para poder permitir acceder a la propiedad de los modales
      y ejecutar el menu de cierre de sesion
   ,function(t){t.preventDefault(),t.stopPropagation(),e.toggle()} 
   
   */