<template>
  <!-- ### $App Screen Content ### -->
    <main class='main-content bgc-grey-100'>
        <div id='mainContent'>
            <div class="container-fluid">
              <el-card class="box-card">
                <div slot="header" class="clearfix">
                  <span>Artículos</span>
                  <el-button style="float: right; padding: 3px 0"  @click="mostrarModal('articulo','registrar')" type="text">Registrar</el-button>
                </div>
                <div  class="text item">
                  <el-table
                    :data="arrayArticulos.filter(data => !search ||  data.Nombre.toLowerCase().includes(search.toLowerCase()) || data.Fecha.toLowerCase().includes(search.toLowerCase()) || data.Descripcion.toLowerCase().includes(search.toLowerCase()) )"
                    style="width: 100%"
                    max-height="330">
                    <el-table-column
                    label="id"
                    prop="id">
                    </el-table-column>
                    <el-table-column
                    label="Nombre"
                    prop="Nombre">
                    </el-table-column>
                    <el-table-column
                    label="Descripcion"
                    prop="Descripcion">
                    </el-table-column>
                    <el-table-column
                    label="Fecha"
                    prop="Fecha">
                    </el-table-column>
                    <el-table-column
                    label="Precio de compra"
                    prop="PrecioC">
                    </el-table-column>
                    <el-table-column
                    align="right">
                    <template slot="header" slot-scope="scope">
                        <el-input
                        v-model="search"
                        size="mini"
                        placeholder="Buscar"/>
                    </template>
                    <template slot-scope="scope">
                        <el-button
                        size="medium"
                        @click="mostrarModal('articulo','actualizar',scope.row)" type="primary" circle><i class="el-icon-edit"></i></el-button>
                        
                    </template>
                    </el-table-column>
                  </el-table>
                </div>
              </el-card>
                <a-modal :width="800"  v-model="Modal" :title="tituloModal" on-ok="handleOk">
                  <template slot="footer">
                    <el-button key="back" @click="cerrarModal" >
                      Regresar
                    </el-button>
                    <el-button  type="success"  v-if="Accion==0" @click="submitForm('ruleForm')">
                      Guardar
                    </el-button>
                    <el-button type="success"  v-if="Accion==1" @click="submitForm('ruleForm')">
                      Actualizar
                    </el-button>
                  </template>
                  <el-form size="small" :label-position="labelPosition" status-icon :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
                    <a-row :gutter="16">
                      <a-col :xs="24" :sm="12" :md="8">
                        <el-form-item label="" >
                          <template v-if="AccionImagen==0 || ActualizarImagen==1">
                              <img-inputer class="img-inputer--large" v-model="file" theme="light" size="large"/>
                          </template>
                          <template v-else>
                            <div class="demo-image__preview">
                              <el-image 
                                style="width: 240px; height: 200px"
                                :src="'public/img/'+Imagen" 
                                :preview-src-list="srcList">
                              </el-image>
                            </div>
                          </template>
                        </el-form-item>
                      </a-col>
                      <a-col xs:="24" :sm="12" :md="8" >
                        <el-form-item  label="Categoría" prop="Categoria">
                          <el-select  v-model="ruleForm.Categoria" placeholder="Seleccione">
                            <el-option  value="">Seleccione</el-option>
                            <el-option  v-for="categoria in arrayCategoria" :key="categoria.id" :value="categoria.id" :label="categoria.Nombre"></el-option>
                          </el-select>
                        </el-form-item>
                      </a-col>
                      <a-col xs:="24" :sm="12" :md="8">
                          <el-form-item label="Nombre" prop="Nombre">
                            <el-input  suffix-icon="el-icon-info"  v-model="ruleForm.Nombre"></el-input>
                          </el-form-item>
                      </a-col>
                      <a-col xs:="24" :sm="12" :md="8">
                          <el-form-item label="Descripción" prop="Descripcion">
                            <el-input suffix-icon="el-icon-document" v-model="ruleForm.Descripcion"></el-input>
                          </el-form-item>
                      </a-col>
                      <a-col xs:="24" :sm="12" :md="8">
                        <el-form-item label="Precio de Compra" prop="PrecioC">
                          <a-input-number
                            v-model.number="ruleForm.PrecioC"
                            :default-value="1"
                            :formatter="value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')"
                            :parser="value => value.replace(/\$\s?|(,*)/g, '')"
                            
                          />
                          <!-- <el-input suffix-icon="el-icon-s-shop" v-model.number="ruleForm.PrecioC"></el-input> -->
                        </el-form-item>
                      </a-col>
                      <a-col xs:="24" :sm="12" :md="8">
                        <el-form-item label="Stock" prop="Stock">
                          <el-input-number :min="1" suffix-icon="el-icon-s-shop" v-model.number="ruleForm.Stock"></el-input-number >
                        </el-form-item>
                      </a-col>
                    </a-row>
                  </el-form>
                </a-modal>
            </div>
        </div>
        
    </main>
</template>
<script>
import Swal from 'sweetalert2/dist/sweetalert2.js'
import VueEasyLightbox from 'vue-easy-lightbox'
   export default {
    data() {
      var checkStock = (rule, value, callback) => {
        if (value) {
          setTimeout(() => {
            if (!Number.isInteger(value)) {
              callback(new Error('Por favor ingrese solo números'));
            } else {
              callback();
              // if (value < 18) {
              //   callback(new Error('Age must be greater than 18'));
              // } else {
              //   callback();
              // }
            }
          }, 1000);
        }else{
          callback();
        }
      };
      return { 
        //tabla
        search:'',
        //Articulo
        arrayArticulos:[],
        ID_Articulo:0,
        //categoria
        arrayCategoria:[],
        //modal
        Modal:false,
        tituloModal:'',
        //imagen
        visible:false,
        AccionImagen : 0,
        ActualizarImagen : 0,
        Imagen : '',
        file : null,
        imgs: '',  // Img Url , string or Array
        index: 0,   // default
        srcList: [],
        //Formulario
        labelPosition: 'top',
        Titulo:'',
        Accion:0,
        ruleForm: {
          Categoria: '',
          Nombre: '',
          Descripcion: '',
          PrecioC: '',
          Stock:1
        },
        rules: {
          Categoria: [
            { required: true, message: 'Por favor seleccione una categoría', trigger: 'change' },
          ],
          Nombre: [
            { required: true, message: 'Por favor ingrese un nombre', trigger: 'change' },
            { min: 4, message: 'La longitud debe ser mayor 3 caracteres', trigger: 'blur' },
          ],
          Descripcion: [
            { required: false, message: 'Puede o no ingresar este campo', trigger: 'change' },
            { min: 4, message: 'La longitud debe ser mayor a 3 caracteres', trigger: 'blur' }
          ],
          PrecioC: [
            { required: true, message: 'Por favor ingrese el precio de compra', trigger: 'change || blur' },
            { type: 'number', message: 'El precio solo puede ser valor númerico', trigger: 'blur' }
          ],
          Stock: [
            { validator: checkStock, trigger: 'blur' }
          ],
        }
      };
    },
    components: {   
      VueEasyLightbox
    },
    methods: {
      //imagen
      showSingle() {
          this.imgs = 'public/img/' + this.Imagen;
          this.show()
      },
      show() {
          this.visible = true
      },
      handleHide() {
          this.visible = false
      },
      //formulario
      submitForm(formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            if(this.Accion==0){
              this.Titulo='¿Desea registrar el artículo?';
            }else{
              this.Titulo='¿Desea actualizar el artículo';
            }
            const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
            title: this.Titulo,
            text: "Presione Aceptar o Cancelar para regresar",
            icon: 'question',
            showCancelButton: true,
            cancelButtonText: 'Cancelar',
            confirmButtonText: 'Aceptar',
            reverseButtons: true
            }).then((result) => {
            if (result.value) {
                let me=this;
                if(me.Accion==0){
                  me.registrarArticulo();
                }else{
                  me.actualizarArticulo();
                }
            } else if (
                /* Read more about handling dismissals below */
                result.dismiss === Swal.DismissReason.cancel
            ) {
                
            }
            })
          } else {
              console.log('error submit!!');
              return false;
          }
      });
      },
      registrarArticulo(){
        let me=this;
        //Creamos el formData
        var data = new  FormData();
        data.append('ID_Categoria', this.ruleForm.Categoria);
        data.append('Nombre', this.ruleForm.Nombre);
        data.append('Descripcion', this.ruleForm.Descripcion);
        data.append('PrecioC', this.ruleForm.PrecioC);
        data.append('Stock', this.ruleForm.Stock);
        //Añadimos la imagen seleccionada
        data.append('File', this.file);
        //Añadimos el método POST dentro del formData
        // Como lo hacíamos desde un formulario simple _(no ajax)_
        data.append('_method', 'post');
        axios.post('/articulo/registrar',data).then(function (response) {
            me.Modal=false;
            Swal.fire('Artículo registrado','','success');
            me.listarArticulos();
            
        })
        .catch(function (error) {
            // handle error
            Swal.fire('Ocurrio un error','','error');
        })
        .finally(function () {
            // always executed
        });
      },
      actualizarArticulo(){
        let me=this;
        axios.put('/articulo/actualizar',{
            'ID' : this.ID_Articulo,
            'ID_Categoria' : this.ruleForm.Categoria,
            'Nombre' : this.ruleForm.Nombre,
            'Descripcion' : this.ruleForm.Descripcion,
            'PrecioC' : this.ruleForm.PrecioC,
            'Stock' : this.ruleForm.Stock,
        }).then(function (response) {
            me.Modal=false;
            Swal.fire('Artículo actualizado','','success');
            me.listarArticulos();
        })
        .catch(function (error) {
            // handle error
            Swal.fire('Ocurrio un error','','error');
        })
        .finally(function () {
            // always executed
        });
      },
      mostrarModal(modelo,accion,data=[]) {
        switch(modelo){
          case 'articulo':{
              switch(accion){
                  case 'registrar':{
                    if(this.$refs.ruleForm){
                      this.resetForm('ruleForm'); 
                    }
                    this.limpiarCampos();
                    this.Accion=0;
                    this.AccionImagen = 0;    
                    this.tituloModal='Registrar Artículo';
                    this.Modal = true;
                    break;
                  }
                  case 'actualizar':{
                    this.Accion=1;
                    this.AccionImagen = 1;
                    this.visible=false;
                    this.tituloModal='Actualizar Artículo';
                    this.Modal = true;
                    this.ID_Articulo     =   data['id'];
                    this.ruleForm.Categoria   =   data['ID_Categoria'];
                    this.ruleForm.Nombre         =   data['Nombre'];
                    this.ruleForm.Descripcion         =   data['Descripcion'];
                    this.ruleForm.PrecioC =   data['PrecioC'];
                    this.ruleForm.Stock =   data['Stock'];
                    this.Imagen         =   data['Imagen'];
                    this.srcList.push('public/img/'+data['Imagen']);
                    break;
                  }
              }
          }
      }   
        
      },
      limpiarCampos(){
        this.ruleForm.Nombre ='';
        this.ruleForm.Categoria ='';
        this.ruleForm.Descripcion ='';
        this.ruleForm.PrecioC ='';
        this.ruleForm.Stock ='';
      },
      cerrarModal(){
        this.Modal=false;
      },
      //funcionalidades, registrar, actualizar etc..
      listarArticulos(){
          let me=this;
          var url = '/articulo';
          axios.get(url).then(function (response) {
              // handle success
              var respuesta = response.data;
              me.arrayArticulos=respuesta.articulos;
          })
          .catch(function (error) {
              // handle error
              console.log(error);
          })
          .finally(function () {
              // always executed
          });
      },
      listarCategorias(){
        // Make a request for a user with a given ID
        let me=this;
        var url = '/categoria/seleccionar_categoria';
        axios.get(url).then(function (response) {
            // handle success
            
            var respuesta = response.data;
            me.arrayCategoria=respuesta.categorias;
            //me.pagination = respuesta.pagination;
        })
        .catch(function (error) {
            // handle error
            console.log(error);
        })
        .finally(function () {
            // always executed
        });
      },
      resetForm(formName) {
          this.$refs[formName].resetFields();
          this.ID_Articulo=0;
          this.Imagen='';
      },
    },
    mounted(){
      this.listarArticulos();
      this.listarCategorias();
    },
  }
</script>
<style >
  .img-inputer--large{
    width:220px;
    height:200px;
  }
    @media (max-width: 600px) {
  .facet_sidebar {
    display: none;
  }
}
     
</style>