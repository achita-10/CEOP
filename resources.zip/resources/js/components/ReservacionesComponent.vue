<template>
    <!-- ### $App Screen Content ### -->
    <main class='main-content bgc-grey-100'>
        <div id='mainContent'>
            <div class="container-fluid">
                
                <!-- <h4 class="c-grey-900 mT-10 mB-30">Clientes</h4> -->
                <div class="row">
                
                    <div class="col-md-12">
                        <div class="bgc-white bd bdrs-3 p-20 mB-20">
                            <h4 class="c-grey-900 mB-20">Reservaciones</h4>
                            <div class="table-responsive">
                                <table id="tabla_reservaciones" class="display table table-striped table-hover" >
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Nombre</th>
                                            <th>Apellido_P</th>
                                            <th>Apellido_M</th> 
                                            <th>Horario</th> 
                                            <th>Servicio</th> 
                                            <th style="width: 10%">Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="reservacion in arrayReservaciones" :key="reservacion.ID">
                                            <td v-text="reservacion.ID"></td>
                                            <td v-text="reservacion.Nombre" ></td>
                                            <td v-text="reservacion.Apellido_P"></td>
                                            <td v-text="reservacion.Apellido_M"></td>
                                            <td v-text="reservacion.Horario"></td>
                                            <td>
                                                <div v-if="reservacion.Servicio==1">
                                                    <span class="alert alert-primary">Libre</span>
                                                </div>
                                                <div v-else>
                                                    <span class="alert alert-success">Entrenador</span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-button-action">
                                                    <button @click="mostrar_Modal('reservacion','actualizar',reservacion)" type="button"   title="Actualizar Información" class="btn btn-link btn-primary btn-lg" >
                                                        <i class="ti-pencil"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <!-- Modal -->
        <div class="modal fade" id="modal_agendar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="" v-text="tituloModal" ></h5>
                <button @click="cerrarModal()" type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <form class="container"  action="/profile">
                    
                    <div class="modal-body">
                        
                        <div class="row">
                            <div class="col-sm-6 col-md-4 mb-3">
                                <div class="form-group">
                                    <label for="">Horario</label>
                                    <input v-model="Horario" type="time" class="form-control"  placeholder="Horario" v-focus>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4 mb-3">
                                <div class="form-group">
                                    <label for="">Servicio</label>
                                    <select @click="seleccionServicio()" v-model="Servicio" id="" class="form-control">
                                        <option value="0">Seleccione</option>
                                        <option value="1">Libre</option>
                                        <option value="2">Entrenador</option>
                                    </select>
                                </div>
                            </div>
                            <template v-if="Servicio==2">
                                <div class="col-sm-6 col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="">Tipo Entrenador</label>
                                        <select v-model="Tipo_E" @click="seleccioneTipoEntrenador()" id="" class="form-control">
                                            <option value="0">Seleccione</option>
                                            <option value="1">Interno</option>
                                            <option value="2">Particular</option>
                                        </select>
                                    </div>
                                </div>
                            </template>
                            <template v-if="Tipo_E==1 && Servicio==2">
                                <div class="col-sm-6 col-md-4 mb-3">
                                    <div class="form-group">
                                        <label for="">Entrenador</label>
                                        <select v-model="Entrenador"  id="" class="form-control">
                                            <option value="0">Seleccione</option>
                                            <option v-for="entrenador in arrayEntrenador" :key="entrenador.id" :value="entrenador.ID" v-text="entrenador.Nombre+' '+entrenador.Apellido_P+' '+entrenador.Apellido_M"></option>
                                        </select>
                                    </div>
                                </div>
                            </template>
                        <!-- </div>
                        <div class="row"> -->
                            
                            <div class="col-sm-6 col-md-4">
                                <label for="">Pago</label>
                                <input v-model="Pago" type="number" class="form-control"  >
                            </div>
                        </div>
                        
                        
                    </div>
                    <div class="modal-footer">
                        <button @click="actualizarReservacion()" type="button" class="btn btn-primary">Guardar</button>
                        <button @click="cerrarModal()" type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </main>
</template>
<!--

Calcular Edad
    Route::get('/get-age',function(){
        $fecha_nacimiento  = "1990-10-23";
        $edad = \Carbon\Carbon::parse($fecha_nacimiento )->age;
        return $edad;

    });
-->
<script>
 import Swal from 'sweetalert2/dist/sweetalert2.js'
    export default {
         data(){
            return{
                arrayReservaciones:[],
                arrayEntrenador:[],
                ID_Reservacion:0,
                ID_Cliente:0,
                
                Tipo:2,
                tituloModal:"",
                tipoAccion:1,
                Horario:"",
                Entrenador:0,
                Temporada:1,
                Tipo_E:0,
                Servicio:0,
                Pago :0,
            }
        },
        directives: {
            focus: {
                inserted: function (el) {
                    el.focus()
                }
            }
        },
        methods:{
            seleccioneTipoEntrenador(){
                if(this.Tipo_E=="0" || this.Tipo_E=="1"){
                    let me=this;
                    var url = '/persona/'+2;
                    axios.get(url).then(function (response) {
                        // handle success
                        var respuesta = response.data;
                        me.arrayEntrenador=respuesta.personas;
                        
                    })
                    .catch(function (error) {
                        // handle error
                        console.log(error);
                    })
                    .finally(function () {
                        // always executed
                    });
                }else {
                    this.Entrenador=0;
                }
            },
            seleccionServicio(){
                if(this.Servicio=='1'){
                    this.Tipo_E=0;
                    this.Entrenador=0;
                }
            },
            tablaReservaciones(){
                $(document).ready(function() {
                    $('#tabla_reservaciones').DataTable();
                });     
            },
            listarReservaciones(){
                let me=this;
                var url = '/reservaciones';
                axios.get(url).then(function (response) {
                    // handle success
                    var respuesta = response.data;
                    me.arrayReservaciones=respuesta.reservaciones;
                    
                    me.tablaReservaciones();
                })
                .catch(function (error) {
                    // handle error
                    console.log(error);
                })
                .finally(function () {
                    // always executed
                });
            },
            actualizarReservacion(){
                //para actualizar se utiliza el metodo put de axios
                // if(this.validarCliente()){
                //     return;
                // }else{
                const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                title: '¿Desea actualizar la reservación?',
                text: "Presione Aceptar, o Cancelar para regresar",
                icon: 'question',
                showCancelButton: true,
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Aceptar',
                reverseButtons: true
                }).then((result) => {
                if (result.value) {
                    let me=this;
                    //Las variables Nombre y Descripcion son las definidas en la funcion data
                    axios.put('/reservacion/actualizar',{
                        'ID'    :   this.ID_Reservacion,
                        'ID_Cliente':this.ID_Cliente,
                        'Horario':this.Horario,
                        'Servicio':this.Servicio,
                        'Temporada':this.Temporada,
                        'Tipo_E':this.Tipo_E,
                        'Entrenador':this.Entrenador,
                        'Pago':this.Pago,
                    }).then(function (response) {
                        me.cerrarModal();
                        Swal.fire('Reservación actualizada','','success');
                        me.listarReservaciones();
                        
                        
                        
                    })
                    .catch(function (error) {
                        // handle error
                        console.log(error);
                    })
                    .finally(function () {
                        // always executed
                    });
                } else if (
                    /* Read more about handling dismissals below */
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    
                }
                });
                
            // }
            },
            
            cerrarModal(){
                $('#modal_agendar').modal('hide');
                this.ID_Reservacion=0;
                this.ID_Cliente=0;
                this.Horario="";
                this.Servicio=0;
                this.Temporada='';
                this.Tipo_E=0;
                this.Entrenador=0;
                this.Pago=0;
               
            },
            mostrar_Modal(modelo,accion,data=[]){
                switch(modelo){
                    case 'reservacion':{
                        switch(accion){
                            case 'registrar':{
                                jQuery('#modal_entrenador').modal('show');
                                this.Nombre         =   '';
                                this.Apellido_P =   '';
                                this.Apellido_M  =   '';
                                this.Fecha_Nac      =   '';
                                this.Sexo="";
                                
                                this.tituloModal        =   'Entrenador Nuevo';
                                this.tipoAccion         =   1;
                                break;
                            }
                            case 'actualizar':{
                                jQuery('#modal_agendar').modal('show');
                                this.tituloModal    =   'Actualizar Reservación';
                                this.tipoAccion     =   2;
                                this.ID_Reservacion =   data['ID'];
                                this.ID_Cliente     =   data['ID_Cliente'];
                                this.Horario        =   data['Horario'];
                                this.Servicio       =   data['Servicio'];
                                this.Tipo_E         =   data['Tipo_E'];
                                this.Entrenador     =   data['Entrenador'];
                                this.Pago           =   data['Pago'];
                                
                                break;
                            }
                        }
                    }
                }   
            },
        },
        mounted() {
            this.listarReservaciones();
            this.seleccioneTipoEntrenador();
        }
    }
</script>

