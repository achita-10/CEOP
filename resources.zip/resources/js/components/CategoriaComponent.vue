<template>
    <!-- ### $App Screen Content ### -->
    <main class='main-content bgc-grey-100'>
        <div id='mainContent'>
            <div class="container-fluid">
                <div>
                    <a-card
                        style="width:100%"
                        title="Categorías"
                        >
                        <a slot="extra" href="#" @click="mostrar_Modal('categoria','registrar')">Registrar</a>
                        <!-- <div class="table-responsive">
                            <table id="tabla_categorias" class="display table table-striped table-hover" >
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nombre</th>
                                        <th>Descripción</th>
                                        <th>Fecha</th> 
                                        <th>Estado</th> 
                                        <th style="width: 10%">Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="categoria in arrayCategorias" :key="categoria.id">
                                        <td v-text="categoria.id"></td>
                                        <td v-text="categoria.Nombre" ></td>
                                        <td v-text="categoria.Descripcion"></td>
                                        <td v-text="categoria.Fecha"></td>
                                        <td>
                                            <div v-if="categoria.Condicion==1">
                                                <span class="alert alert-primary">Disponible</span>
                                            </div>
                                            <div v-else>
                                                <span class="alert alert-danger">Desactivada</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-button-action">
                                                <a-button @click="mostrar_Modal('categoria','actualizar',categoria)" type="primary" shape="circle"> Editar</a-button>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div> -->
                        <el-table
                            :data="arrayCategorias.filter(data => !search || data.Nombre.toLowerCase().includes(search.toLowerCase()) || data.Fecha.toLowerCase().includes(search.toLowerCase()) || data.Descripcion.toLowerCase().includes(search.toLowerCase()))"
                            style="width: 100%"
                            max-height="330">
                            <el-table-column
                            label="id"
                            prop="id">
                            </el-table-column>
                            <el-table-column
                            label="Nombre"
                            prop="Nombre">
                            </el-table-column>
                            <el-table-column
                            label="Descripcion"
                            prop="Descripcion">
                            </el-table-column>
                            <el-table-column
                            label="Fecha"
                            prop="Fecha">
                            </el-table-column>
                            <el-table-column
                            label="Estado"
                            prop="Condicion">
                            </el-table-column>
                            <el-table-column
                            align="right">
                            <template slot="header" slot-scope="scope">
                                <el-input
                                v-model="search"
                                size="mini"
                                placeholder="Buscar"/>
                            </template>
                            <template slot-scope="scope">
                                <el-button
                                size="medium"
                                @click="mostrar_Modal('categoria','actualizar',scope.row)" type="primary" circle><i class="el-icon-edit"></i></el-button>
                            </template>
                            </el-table-column>
                        </el-table> 
                    </a-card>
                    <a-modal v-model="Modal" :title="tituloModal" on-ok="handleOk">
                        <template slot="footer">
                            <a-button key="back" @click="handleOk" >
                            Regresar
                            </a-button>
                            <el-button key="" type="success"  v-if="Accion==0" @click="submitForm('ruleForm')">
                            Guardar
                            </el-button>
                            <el-button key="" type="success"  v-if="Accion==1" @click="submitForm('ruleForm')">
                            Actualizar
                            </el-button>
                        </template>
                        <el-form :label-position="labelPosition" status-icon :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
                            <a-row :gutter="16">
                                <a-col xs:="24" :sm="24" :md="12">
                                    <el-form-item label="Nombre" prop="Nombre">
                                        <el-input suffix-icon="el-icon-info" size="medium" v-model="ruleForm.Nombre"></el-input>
                                    </el-form-item>
                                </a-col>
                                <a-col xs:="24" :sm="24" :md="12">
                                    <el-form-item label="Descripción" prop="Descripcion">
                                        <el-input suffix-icon="el-icon-document" size="medium" v-model="ruleForm.Descripcion"></el-input>
                                    </el-form-item>
                                </a-col>
                            </a-row>
                        </el-form>
                    </a-modal>                   
                </div>
            </div>
        </div>
        
    </main>
</template>
<!--

Calcular Edad
    Route::get('/get-age',function(){
        $fecha_nacimiento  = "1990-10-23";
        $edad = \Carbon\Carbon::parse($fecha_nacimiento )->age;
        return $edad;

    });
-->
<script>
 import Swal from 'sweetalert2/dist/sweetalert2.js'
    export default {
         data(){
            return{
                //tabla
                search:'',
                //variables
                arrayCategorias:[],
                ID_Categoria:0,
                tituloModal:'',
                //modal
                Modal:false,
                Titulo:'',
                Accion:0,
                labelPosition: 'top',
                //formulario
                ruleForm: {
                    Nombre: '',
                    Descripcion: '',
                },
                rules: {
                    Nombre: [
                        { required: true, message: 'Por favor ingrese un nombre', trigger: 'change' },
                        { min: 4, message: 'La longitud debe ser mayor 3 caracteres', trigger: 'blur' },
                    ],
                    Descripcion: [
                        { required: false, message: 'Puede o no ingresar este campo', trigger: 'change' },
                        { min: 4, message: 'La longitud debe ser mayor a 4 caracteres', trigger: 'blur' }
                    ],
                },
            }
        },
        
        methods:{
            //modal
            showModal() {
                this.Modal = true;
            },
            handleOk() {
                this.Modal = false;
            },
            //funcionalidades, registrar, actualizar etc..
            listarCategorias(){
                let me=this;
                var url = '/categoria';
                axios.get(url).then(function (response) {
                    // handle success
                    var respuesta = response.data;
                    me.arrayCategorias=respuesta.categorias;
                })
                .catch(function (error) {
                    // handle error
                    console.log(error);
                })
                .finally(function () {
                    // always executed
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            },
             //formulario
            submitForm(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        if(this.Accion==0){
                            this.Titulo='¿Desea registrar la categoría?';
                        }else{
                            this.Titulo='¿Desea actualizar la categoría';
                        }
                        const swalWithBootstrapButtons = Swal.mixin({
                        customClass: {
                            confirmButton: 'btn btn-success',
                            cancelButton: 'btn btn-danger'
                        },
                        buttonsStyling: false
                        })

                        swalWithBootstrapButtons.fire({
                        title: this.Titulo,
                        text: "Presione Aceptar o Cancelar para regresar",
                        icon: 'question',
                        showCancelButton: true,
                        cancelButtonText: 'Cancelar',
                        confirmButtonText: 'Aceptar',
                        reverseButtons: true
                        }).then((result) => {
                        if (result.value) {
                            let me=this;
                            if(me.Accion==0){
                                me.registrarCategoria();
                            }else{
                                me.actualizarCategoria();
                            }
                        } else if (
                            /* Read more about handling dismissals below */
                            result.dismiss === Swal.DismissReason.cancel
                        ) {
                            
                        }
                        })
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            registrarCategoria(){
                let me=this;
                axios.post('/categoria/registrar',{
                    'Nombre':this.ruleForm.Nombre,
                    'Descripcion':this.ruleForm.Descripcion,
                }).then(function (response) {
                    Swal.fire('Categoría registrada','','success');
                    me.handleOk();
                    me.listarCategorias();
                })
                .catch(function (error) {
                    // handle error
                    console.log(error);
                })
                .finally(function () {
                    // always executed
                });
            },
            actualizarCategoria(formName){
                let me=this;
                    //Las variables Nombre y Descripcion son las definidas en la funcion data
                axios.put('/categoria/actualizar',{
                    'ID': this.ID_Categoria,
                    'Nombre':this.ruleForm.Nombre,
                    'Descripcion':this.ruleForm.Descripcion,
                }).then(function (response) {
                    Swal.fire('Categoría actualizada','','success');
                    me.handleOk();
                    me.listarCategorias();
                })
                .catch(function (error) {
                    // handle error
                    console.log(error);
                })
                .finally(function () {
                    // always executed
                });
            },
            limpiarCampos(){
                this.ruleForm.Nombre="";
                this.ruleForm.Descripcion="";
            },
            mostrar_Modal(modelo,accion,data=[]){
                switch(modelo){
                    case 'categoria':{
                        switch(accion){
                            case 'registrar':{
                                if(this.$refs.ruleForm){
                                    this.resetForm('ruleForm'); 
                                }
                                this.Modal = true;
                                this.tituloModal    =   'Registrar categoría';
                                this.Accion=0;
                                this.limpiarCampos();
                                break;
                            }
                            case 'actualizar':{
                                this.Modal = true;
                                this.Accion=1;
                                this.tituloModal    =   'Actualizar categoría';
                                this.ID_Categoria     =   data['id'];
                                this.ruleForm.Nombre         =   data['Nombre'];
                                this.ruleForm.Descripcion=   data['Descripcion'];
                                break;
                            }
                        }
                    }
                }   
            },
        },
        mounted() {
            this.listarCategorias();
        }
    }
</script>
