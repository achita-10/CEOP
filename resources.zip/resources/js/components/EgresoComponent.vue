<template>
  <!-- ### $App Screen Content ### -->
    <main class='main-content bgc-grey-100'>
        <div id='mainContent'>
            <div class="container-fluid">
              <template v-if="listado==0">
                <el-card class="box-card">
                  <div slot="header" class="clearfix">
                    <span>Salida de Mercancía</span>
                    <el-button style="float: right; padding: 3px 0"  @click="vistaIngreso()" type="text">Registrar salida</el-button>
                  </div>
                  <div  class="text item">
                    <el-table
                      :data="arrayEgresos.filter(data => !search ||  data.Fecha.toLowerCase().includes(search.toLowerCase()) || data.Total.toLowerCase().includes(search.toLowerCase())  )"
                      style="width: 100%"
                      max-height="330">
                      <el-table-column
                      label="id"
                      prop="id">
                      </el-table-column>
                      <el-table-column
                      label="Fecha"
                      prop="Fecha">
                      </el-table-column>
                      <el-table-column
                      label="Total"
                      prop="Total">
                      </el-table-column>
                      <el-table-column
                      label="Estado"
                      prop="Estado">
                      </el-table-column>
                      <el-table-column
                      align="right">
                      <template slot="header" slot-scope="scope">
                          <el-input
                          v-model="search"
                          size="mini"
                          placeholder="Buscar"/>
                      </template>
                      <template slot-scope="scope">
                          <!-- <el-button
                          size="medium"
                          @click="agregarDetalle(scope.row)" type="primary" circle><i class="el-icon-circle-plus"></i></el-button>
                           -->
                      </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </el-card>
              </template>
              <template v-else>
                  <el-card class="box-card">
                    <div slot="header" class="clearfix">
                      <span><el-button style="float: left; "  @click="vistaTabla()" plain>Regresar</el-button></span>
                      <el-button style="float: right;"  @click="modalArticulos()" type="warning" plain>Artículos</el-button>
                      <el-button style="float: right; "  @click="registrarEgreso()"  type="success" plain>Guardar</el-button>
                    </div>
                    <div class="text item">
                      <!-- <el-form size="small" :label-position="labelPosition" status-icon :model="ruleFormIngreso" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
                        <a-row :gutter="24">
                          <a-col xs:="24" :sm="12" :md="8" >
                            <el-form-item  label="Proveedor" prop="Proveedor">
                              <el-select  v-model="ruleFormIngreso.Proveedor" placeholder="Seleccione">
                                <el-option  value="">Seleccione</el-option>
                                <el-option  v-for="proveedor in arrayProveedor" :key="proveedor.id" :value="proveedor.id" :label="proveedor.Nombre"></el-option>
                              </el-select>
                            </el-form-item>
                          </a-col>
                          <a-col xs:="24" :sm="12" :md="8">
                              <el-form-item label="Comprobante" prop="Comprobante">
                                <el-input  suffix-icon="el-icon-info"  v-model="ruleFormIngreso.Comprobante"></el-input>
                              </el-form-item>
                          </a-col>
                          <a-col xs:="24" :sm="12" :md="8">
                              <el-form-item label="Folio" prop="Folio">
                                <el-input suffix-icon="el-icon-document" v-model="ruleFormIngreso.Folio"></el-input>
                              </el-form-item>
                          </a-col>
                          <a-col xs:="24" :sm="6" :md="4">
                            <el-button  type="success" @click="registrarIngreso('ruleForm')" >
                              Guardar
                            </el-button>
                          </a-col>
                        </a-row>
                      </el-form> -->
                      <!-- <el-card class="box-card"> -->
                        <!-- <el-table
                          :data="arrayDetalle.filter(data => !search ||  data.Nombre.toLowerCase().includes(search.toLowerCase()) || data.Precio.toLowerCase().includes(search.toLowerCase()) || data.Cantidad.toLowerCase().includes(search.toLowerCase())  )"
                          style="width: 100%"
                          max-height="330">
                          <el-table-column
                          label="id"
                          prop="ID_Articulo">
                          </el-table-column>
                          <el-table-column
                          label="Nombre"
                          prop="Nombre">
                          </el-table-column>
                          <el-table-column
                          label="Cantidad"
                          prop="Cantidad">
                          
                          <el-input-number v-model="arrayDetalle.Cantidad" controls-position="right" :min="1" ></el-input-number>
                          </el-table-column>
                          <el-table-column
                          label="Precio de compra"
                          prop="Precio">
                          
                          </el-table-column>
                          <el-table-column
                          align="right">
                          <template slot="header" slot-scope="scope">
                              <el-input
                              v-model="search"
                              size="mini"
                              placeholder="Buscar"/>
                          </template>
                          <template slot-scope="scope">
                              <el-button
                              size="medium"
                              @click="eliminarArticulo('articulo','actualizar',scope.row)" type="primary" circle><i class="el-icon-circle-plus"></i></el-button>
                              
                          </template>
                          </el-table-column>
                        </el-table> -->
                        <!-- <el-button  type="success" @click="registrarEgreso()" >
                          Guardar
                        </el-button> -->
                        <div class="table-responsive">
                                <table id="" class="display table table-striped table-hover" >
                                    <thead>
                                        <tr>
                                            <th>Artículo</th>
                                            <th>Precio de venta</th>
                                            <th>Cantidad</th>
                                            <th>SubTotal</th>
                                            <th>Opciones</th>
                                        </tr>
                                    </thead>
                                    <!--Si existe algun detalle del articulo se mostrarán los registro-->
                                    <tbody v-if="arrayDetalle.length">
                                        <tr v-for="(detalle,indice) in arrayDetalle" :key="detalle.id">
                                            <td v-text="detalle.Nombre">
                                            </td>
                                            <td > 
                                              <a-input-number
                                                v-model.number="detalle.Precio"
                                                :formatter="value => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')"
                                                :parser="value => value.replace(/\$\s?|(,*)/g, '')"
                                              />
                                            </td>
                                            <td>
                                              <!--La directiva v-show mostrara el contenido cuando se cumpla la condicion-->
                                              <span style="color:red;" v-show="detalle.Cantidad>detalle.Stock "> Stock: {{detalle.Stock }}</span>
                                              <el-input-number  :min="1"  v-model.number="detalle.Cantidad"></el-input-number >
                                            </td>
                                            <td>
                                                {{detalle.Precio*detalle.Cantidad}}
                                            </td>
                                            <td>
                                              <el-button  type="danger" @click="eliminarDetalle(indice)" circle>
                                                <i class="el-icon-remove" ></i>
                                              </el-button>
                                            </td>
                                        </tr>
                                        <tr style="background-color: #CEECF5;">
                                            <td colspan="4" align="right"><strong>Total Parcial:</strong></td>
                                            <td>$ {{Total_Parcial = (Total-Total_Impuesto).toFixed(2)}}</td>
                                        </tr>
                                        <tr style="background-color: #CEECF5;">
                                            <td colspan="4" align="right"><strong>Total Impuesto:</strong></td>
                                            <td>$ {{Total_Impuesto = ((Total*Impuesto)/(1+Impuesto)).toFixed(2)}}</td>
                                        </tr>
                                        <tr style="background-color: #CEECF5;">
                                            <td colspan="4" align="right"><strong>Total Neto:</strong></td>
                                            <td>$ {{ Total = calcularTotal}}</td>
                                        </tr>
                                    </tbody>
                                    <!--de lo contrario se mostrará lo siguiente-->
                                    <tbody v-else>
                                        <tr>
                                            <td colspan="5">No hay artículos agregados</td>
                                        </tr>
                                    </tbody>
                                </table>
                                
                            </div>
                      <!-- </el-card> -->
                    </div>
                  </el-card>
              </template>
              <a-modal :width="800"  v-model="Modal" :title="tituloModal" on-ok="handleOk">
                <template slot="footer">
                  <el-button key="back" @click="cerrarModal" >
                    Regresar
                  </el-button>
                </template>
                <el-table
                  :data="arrayArticulos.filter(data => !search ||  data.Nombre.toLowerCase().includes(search.toLowerCase()) || data.Descripcion.toLowerCase().includes(search.toLowerCase()) )"
                  style="width: 100%"
                  max-height="330">
                  <el-table-column
                  label="id"
                  prop="id">
                  </el-table-column>
                  <el-table-column
                  label="Nombre"
                  prop="Nombre">
                  </el-table-column>
                  <el-table-column
                  label="Descripcion"
                  prop="Descripcion">
                  </el-table-column>
                  <el-table-column
                  label="Stock"
                  prop="Stock">
                  </el-table-column>
                  <el-table-column
                  align="right">
                  <template slot="header" slot-scope="scope">
                      <el-input
                      v-model="search"
                      size="mini"
                      placeholder="Buscar"/>
                  </template>
                  <template slot-scope="scope">
                    <el-button
                        title="Imagen del artículo"
                        size="medium"
                        @click="mostrarImagen(scope.row)" type="primary" circle><i class="el-icon-picture"></i></el-button>
                      <VueEasyLightbox
                        :visible="visible"
                        :imgs="imgs"
                        :index="index"
                        @hide="handleHide"
                        >
                      </VueEasyLightbox>
                      <el-button
                        title="Agregar artículo al detalle"
                        size="medium"
                        @click="agregarDetalle(scope.row)" type="primary" circle><i class="el-icon-circle-plus"></i></el-button>
                  </template>
                  </el-table-column>
                </el-table>
              </a-modal>
            </div>
        </div>
    </main>
</template>
<script>

import Swal from 'sweetalert2/dist/sweetalert2.js'
import VueEasyLightbox from 'vue-easy-lightbox'
   export default {
    data() {
      var checkStock = (rule, value, callback) => {
        if (value) {
          setTimeout(() => {
            if (!Number.isInteger(value)) {
              callback(new Error('Por favor ingrese solo números'));
            } else {
              callback();
              // if (value < 18) {
              //   callback(new Error('Age must be greater than 18'));
              // } else {
              //   callback();
              // }
            }
          }, 1000);
        }else{
          callback();
        }
      };
      return { 
        //error
        Error:[],
        //Proveedor
        arrayProveedor:[],
        ID_Proveedor:0,
        Impuesto : 0.16,
        Total : 0.0,
        Total_Impuesto : 0.0,
        Total_Parcial : 0.0,
        // //modal cantidad
        // visibleCantidad: false,
        //vista
        listado:0,
        arrayDetalle:[],
        //tabla
        search:'',
        //Ingresos
        arrayEgresos:[],
        //Articulos
        arrayArticulos:[],
        ID_Articulo:0,
        //categoria
        arrayCategoria:[],
        //modal
        Modal:false,
        tituloModal:'Artículos',
        //imagen
        visible:false,
        AccionImagen : 0,
        ActualizarImagen : 0,
        Imagen : '',
        file : null,
        imgs: '',  // Img Url , string or Array
        index: 0,   // default
        srcList: [],
        //Formulario
        labelPosition: 'top',
        Titulo:'',
        Accion:0,
        ruleFormIngreso: {
          Proveedor: '',
          Comprobante: '',
          Folio: '',
        },
        rules: {
          Proveedor: [
            { required: true, message: 'Por favor seleccione un proveedor', trigger: 'change' },
          ],
          Comprobante: [
            { required: true, message: 'Por favor ingrese el comprobante', trigger: 'change' },
            { min: 4, message: 'La longitud debe ser mayor 3 caracteres', trigger: 'blur' },
          ],
          Folio: [
            { required: true, message: 'or favor ingrese el folio', trigger: 'change' },
            { min: 4, message: 'La longitud debe ser mayor a 3 caracteres', trigger: 'blur' }
          ],
        }
      };
    },
    components: {   
      VueEasyLightbox
    },
    computed : {
      calcularTotal: function(){
          var resultado = 0;
          for (var i = 0; i < this.arrayDetalle.length; i++) {
              resultado= resultado + (this.arrayDetalle[i].Precio* this.arrayDetalle[i].Cantidad);
          }
          return resultado;
      }
    },
    methods: {
      //imagen
      show() {
          this.visible = true
      },
      handleHide() {
          this.visible = false
      },
      mostrarImagen(data = []){
          this.imgs = 'img/'+data['Imagen'];
          this.show()
      },
      //Proveedor
      listarProveedores(){
          let me=this;
          var url = '/proveedor';
          axios.get(url).then(function (response) {
              // handle success
              var respuesta = response.data;
              me.arrayProveedor=respuesta.personas;
          })
          .catch(function (error) {
              // handle error
              console.log(error);
          })
          .finally(function () {
              // always executed
          });
      },
      //comprobar artículo
      encuentra(id_articulo){
          var sw=0;
          for (var i = 0; i < this.arrayDetalle.length; i++) {
              if(this.arrayDetalle[i].ID_Articulo==id_articulo){
                  sw=true;
              }
              
          }
          return sw;
      },
      eliminarDetalle(indice){
          let me = this;
          me.arrayDetalle.splice(indice,1);
      },
      //Agregar detalle
      agregarDetalle(data=[]){
        let me = this;
        //Verificar si el articulo ya se encuentra en el detalle
        if(me.encuentra(data['id'])){
            Swal.fire('El artículo ya se encuentra agregado','','error')
        }else{
          me.arrayDetalle.push({
            ID_Articulo: data['id'],
            Nombre : data['Nombre'],
            Cantidad : 1,
            Precio : 1,
            Stock : data['Stock'],
          });
        }
      },
      handleCancel(){
        this.visibleCantidad=false;
      },
      //Cambio de vistas
      vistaIngreso(){
        this.listado=1;
        this.listarProveedores();
      },
      vistaTabla(){
        this.listado=0;
        this.arrayDetalle=[];
        this.arrayArticulos=[];
        this.arrayProveedor=[];
        this.listarEgresos();
      },
      
      //formulario
      registrarEgreso() {
        let me=this;
          if(me.arrayDetalle.length<=0){
            Swal.fire('No se han agregado artículos al detalle','','info');
          }else{
            const swalWithBootstrapButtons = Swal.mixin({
              customClass: {
                  confirmButton: 'btn btn-success',
                  cancelButton: 'btn btn-danger'
              },
              buttonsStyling: false
              })
              swalWithBootstrapButtons.fire({
              title: '¿Desea registrar la salida de mercacía?',
              text: "Presione Aceptar o Cancelar para regresar",
              icon: 'question',
              showCancelButton: true,
              cancelButtonText: 'Cancelar',
              confirmButtonText: 'Aceptar',
              reverseButtons: true
              }).then((result) => {
              if (result.value) {
                  
                  axios.post('/egreso/registrar',{
                      'Total':this.Total,
                      'data':this.arrayDetalle,
                  }).then(function (response) {
                      me.Modal=false;
                      Swal.fire('Salida registrada','','success');
                      me.vistaTabla();
                  })
                  .catch(function (error) {
                      // handle error
                      Swal.fire('Ocurrio un error','','error');
                  })
                  .finally(function () {
                      // always executed
                  });
              } else if (
                  /* Read more about handling dismissals below */
                  result.dismiss === Swal.DismissReason.cancel
              ) {
                  
              }
              })
          }
        
        
      },
      modalArticulos() {   
        this.Modal=true;
        this.listarArticulos();
      },
      limpiarCampos(){
        this.ruleForm.Nombre ='';
        this.ruleForm.Categoria ='';
        this.ruleForm.Descripcion ='';
        this.ruleForm.PrecioC ='';
        this.ruleForm.Stock ='';
      },
      cerrarModal(){
        this.Modal=false;
      },
      //funcionalidades, registrar, actualizar etc..
      listarArticulos(){
          let me=this;
          var url = '/articulo';
          axios.get(url).then(function (response) {
              // handle success
              var respuesta = response.data;
              me.arrayArticulos=respuesta.articulos;
          })
          .catch(function (error) {
              // handle error
              console.log(error);
          })
          .finally(function () {
              // always executed
          });
      },
      listarEgresos(){
          let me=this;
          var url = '/egreso';
          axios.get(url).then(function (response) {
              // handle success
              var respuesta = response.data;
              me.arrayEgresos=respuesta.egresos;
          })
          .catch(function (error) {
              // handle error
              console.log(error);
          })
          .finally(function () {
              // always executed
          });
      },
      
      resetForm(formName) {
          this.$refs[formName].resetFields();
          this.ID_Articulo=0;
          this.Imagen='';
      },
    },
    mounted(){
      this.listarEgresos();
    },
  }
</script>
<style >
  
    @media (max-width: 600px) {
  .facet_sidebar {
    display: none;
  }
}
     
</style>