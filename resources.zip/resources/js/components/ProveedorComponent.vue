<template>
    <!-- ### $App Screen Content ### -->
    <main class='main-content bgc-grey-100'>
        <div id='mainContent'>
            <div class="container-fluid">
                <div>
                    <a-card
                        style="width:100%"
                        title="Proveedores"
                        >
                        <a slot="extra" href="#" @click="mostrar_Modal('proveedor','registrar')">Registrar</a>
                        <el-table
                            :data="arrayProveedor.filter(data => !search || data.Nombre.toLowerCase().includes(search.toLowerCase()) )"
                            style="width: 100%"
                            max-height="330">
                            <el-table-column
                            label="id"
                            prop="id">
                            </el-table-column>
                            <el-table-column
                            label="Nombre"
                            prop="Nombre">
                            </el-table-column>
                            <el-table-column
                            label="Dirección"
                            prop="Direccion">
                            </el-table-column>
                            <el-table-column
                            label="Telefono"
                            prop="Telefono">
                            </el-table-column>
                            <el-table-column
                            label="Fecha"
                            prop="created_at">
                            </el-table-column>
                            <el-table-column
                            align="right">
                            <template slot="header" slot-scope="scope">
                                <el-input
                                v-model="search"
                                size="mini"
                                placeholder="Buscar"/>
                            </template>
                            <template slot-scope="scope">
                                <el-button
                                size="medium"
                                @click="mostrar_Modal('proveedor','actualizar',scope.row)" type="primary" circle><i class="el-icon-edit"></i></el-button>
                            </template>
                            </el-table-column>
                        </el-table> 
                    </a-card>
                    <a-modal v-model="Modal" :title="tituloModal" on-ok="handleOk">
                        <template slot="footer">
                            <a-button key="back" @click="handleOk" >
                            Regresar
                            </a-button>
                            <el-button key="" type="success"  v-if="Accion==0" @click="submitForm('ruleForm')">
                            Guardar
                            </el-button>
                            <el-button key="" type="success"  v-if="Accion==1" @click="submitForm('ruleForm')">
                            Actualizar
                            </el-button>
                        </template>
                        <el-form size="medium" :label-position="labelPosition" status-icon :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
                            <a-row :gutter="16">
                                <a-col xs:="24" :sm="12" :md="12">
                                    <el-form-item label="Nombre" prop="Nombre">
                                        <el-input suffix-icon="el-icon-info" v-model="ruleForm.Nombre"></el-input>
                                    </el-form-item>
                                </a-col>
                                <a-col xs:="24" :sm="12" :md="12">
                                    <el-form-item label="Dirección" prop="Direccion">
                                        <el-input suffix-icon="el-icon-document" v-model="ruleForm.Direccion"></el-input>
                                    </el-form-item>
                                </a-col>
                                <a-col xs:="24" :sm="12" :md="12">
                                    <el-form-item label="Telefono" prop="Telefono">
                                        <el-input suffix-icon="el-icon-phone"  v-model.number="ruleForm.Telefono"></el-input>
                                    </el-form-item>
                                </a-col>
                                <a-col xs:="24" :sm="12" :md="12">
                                    <el-form-item label="Correo" prop="Correo">
                                        <el-input suffix-icon="el-icon-document"  v-model="ruleForm.Correo"></el-input>
                                    </el-form-item>
                                </a-col>
                            </a-row>
                        </el-form>
                    </a-modal>                   
                </div>
            </div>
        </div>
        
    </main>
</template>
<!--

Calcular Edad
    Route::get('/get-age',function(){
        $fecha_nacimiento  = "1990-10-23";
        $edad = \Carbon\Carbon::parse($fecha_nacimiento )->age;
        return $edad;

    });
-->
<script>
 import Swal from 'sweetalert2/dist/sweetalert2.js'
    export default {
         data(){
             var checkTelefono = (rule, value, callback) => {
                if (value) {
                setTimeout(() => {
                    if (!Number.isInteger(value)) {
                    callback(new Error('Por favor ingrese solo números'));
                    } else {
                    callback();
                    // if (value < 18) {
                    //   callback(new Error('Age must be greater than 18'));
                    // } else {
                    //   callback();
                    // }
                    }
                }, 1000);
                }else{
                callback();
                }
            };
            return{
                //tabla
                search:'',
                //variables
                arrayProveedor:[],
                ID_Proveedor:0,
                tituloModal:'',
                //modal
                Modal:false,
                Titulo:'',
                Accion:0,
                labelPosition: 'top',
                //formulario
                ruleForm: {
                    Nombre: '',
                    Direccion: '',
                    Correo:'',
                    Telefono:''
                },
                rules: {
                    Nombre: [
                        { required: true, message: 'Por favor ingrese un nombre', trigger: 'change' },
                        { min: 4, message: 'La longitud debe ser mayor 3 caracteres', trigger: 'blur' },
                    ],
                    Direccion: [
                        { required: false, message: 'Puede o no ingresar este campo', trigger: 'change' },
                        { min: 4, message: 'La longitud debe ser mayor a 3 caracteres', trigger: 'blur' }
                    ],
                    Telefono: [
                        { validator: checkTelefono, trigger: 'blur' }
                    ],
                    Correo: [
                        { type:'email', required: false, message: 'El formato debe ser de email', trigger: 'change' },
                        
                    ],
                },
            }
        },
        
        methods:{
            //modal
            showModal() {
                this.Modal = true;
            },
            handleOk() {
                this.Modal = false;
            },
            //funcionalidades, registrar, actualizar etc..
            listarProveedores(){
                let me=this;
                var url = '/persona';
                axios.get(url).then(function (response) {
                    // handle success
                    var respuesta = response.data;
                    me.arrayProveedor=respuesta.personas;
                })
                .catch(function (error) {
                    // handle error
                    console.log(error);
                })
                .finally(function () {
                    // always executed
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            },
             //formulario
            submitForm(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        if(this.Accion==0){
                            this.Titulo='¿Desea registrar al proveedor?';
                        }else{
                            this.Titulo='¿Desea actualizar el proveedor';
                        }
                        const swalWithBootstrapButtons = Swal.mixin({
                        customClass: {
                            confirmButton: 'btn btn-success',
                            cancelButton: 'btn btn-danger'
                        },
                        buttonsStyling: false
                        })

                        swalWithBootstrapButtons.fire({
                        title: this.Titulo,
                        text: "Presione Aceptar o Cancelar para regresar",
                        icon: 'question',
                        showCancelButton: true,
                        cancelButtonText: 'Cancelar',
                        confirmButtonText: 'Aceptar',
                        reverseButtons: true
                        }).then((result) => {
                        if (result.value) {
                            let me=this;
                            if(me.Accion==0){
                                me.registrarProveedor();
                            }else{
                                me.actualizarProveedor();
                            }
                        } else if (
                            /* Read more about handling dismissals below */
                            result.dismiss === Swal.DismissReason.cancel
                        ) {
                            
                        }
                        })
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            registrarProveedor(){
                let me=this;
                axios.post('/persona/registrar',{
                    'Nombre':this.ruleForm.Nombre,
                    'Direccion':this.ruleForm.Direccion,
                    'Telefono':this.ruleForm.Telefono,
                    'Correo':this.ruleForm.Correo,
                }).then(function (response) {
                    Swal.fire('Proveedor registrado','','success');
                    me.handleOk();
                    me.listarProveedores();
                })
                .catch(function (error) {
                    // handle error
                    Swal.fire('Ocurrio un error','','success');
                })
                .finally(function () {
                    // always executed
                });
            },
            actualizarProveedor(formName){
                let me=this;
                    //Las variables Nombre y Direccion son las definidas en la funcion data
                axios.put('/persona/actualizar',{
                    'ID': this.ID_Proveedor,
                    'Nombre':this.ruleForm.Nombre,
                    'Direccion':this.ruleForm.Direccion,
                    'Telefono':this.ruleForm.Telefono,
                    'Correo':this.ruleForm.Correo,
                }).then(function (response) {
                    Swal.fire('Proveedor actualizado','','success');
                    me.handleOk();
                    me.listarProveedores();
                })
                .catch(function (error) {
                    Swal.fire('Ocurrio un error','','success');
                })
                .finally(function () {
                    // always executed
                });
            },
            limpiarCampos(){
                this.ruleForm.Nombre="";
                this.ruleForm.Direccion="";
                this.ruleForm.Telefono="";
                this.ruleForm.Correo="";
            },
            mostrar_Modal(modelo,accion,data=[]){
                switch(modelo){
                    case 'proveedor':{
                        switch(accion){
                            case 'registrar':{
                                if(this.$refs.ruleForm){
                                    this.resetForm('ruleForm'); 
                                }
                                this.Modal = true;
                                this.tituloModal    =   'Registrar proveedor';
                                this.Accion=0;
                                this.limpiarCampos();
                                break;
                            }
                            case 'actualizar':{
                                this.Modal = true;
                                this.Accion=1;
                                this.tituloModal    =   'Actualizar proveedor';
                                this.ID_Proveedor     =   data['id'];
                                this.ruleForm.Nombre         =   data['Nombre'];
                                this.ruleForm.Direccion=   data['Direccion'];
                                this.ruleForm.Telefono=   data['Telefono'];
                                this.ruleForm.Correo=   data['Correo'];
                                break;
                            }
                        }
                    }
                }   
            },
        },
        mounted() {
            this.listarProveedores();
        }
    }
</script>
