@extends('Principal')
@section('contenido')
    <template v-if="menu==1">
        <articulo-component></articulo-component>
    </template>
    <template v-if="menu==2">
        <categoria-component></categoria-component>
    </template> 
    <template v-if="menu==3">
        <ingresos-component></ingresos-component>
    </template> 
    <template v-if="menu==4">
        <proveedor-component></proveedor-component>
    </template> 
    <template v-if="menu==5">
        <egreso-component></egreso-component>
    </template> 
@endsection